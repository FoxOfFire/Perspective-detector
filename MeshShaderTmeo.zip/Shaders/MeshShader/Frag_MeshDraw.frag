#version 450

layout(location = 0) out vec4 FragColor;

uniform sampler2D texImage;

in vec4 ms_out_col;
in vec4 ms_out_task_col;
in vec3 ms_out_norm;
in vec2 ms_out_tex;

uniform bool showMeshlets = false;
uniform bool showTaskGroups = false;

// Directional light source 
uniform vec3 light_dir = vec3(-1,-2,-0.5);

// Light attributes: ambient, diffuse
uniform vec3 La = vec3(0.4, 0.4, 0.4);
uniform vec3 Ld = vec3(0.6, 0.6, 0.6);

void main()
{
	// Ambient
	vec3 ambient = La;

	// Diffuse
	vec3 normal = normalize( ms_out_norm );
	vec3 to_light = normalize( -light_dir );

	float cosa = clamp(dot(normal, to_light), 0, 1);

	vec3 diffuse = cosa*Ld;


	FragColor = vec4(ambient + diffuse, 1) * texture(texImage, ms_out_tex);

	if (showMeshlets) FragColor = ms_out_col;
	if (showTaskGroups) FragColor = ms_out_task_col;
}