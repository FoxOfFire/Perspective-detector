#include "MyApp.h"

#include "SDL_GLDebugMessageCallback.h"
#include "ObjParser.h"
#include "ParametricSurfaceMesh.hpp"
#include "ProgramBuilder.h"

#include <imgui.h>

#include <random>
#include <cmath>

CMyApp::CMyApp() : m_cameraManipulator(m_usedCamera)
{
	// Initializing the cubes
	std::fill_n(m_isVisible.begin(), m_isVisible.size(), true);

	if(!GLEW_NV_mesh_shader)
		SDL_LogError(SDL_LOG_CATEGORY_ERROR, "[GL NV] This hardware does not support mesh shaders.");
	else
		SDL_LogMessage(SDL_LOG_CATEGORY_APPLICATION, SDL_LOG_PRIORITY_INFO, "[GL NV] This hardware supports mesh shaders.");

	GLint max_draw_mesh_tasks_count;
	glGetIntegerv(GL_MAX_DRAW_MESH_TASKS_COUNT_NV, &max_draw_mesh_tasks_count);
	SDL_LogMessage(SDL_LOG_CATEGORY_APPLICATION, SDL_LOG_PRIORITY_INFO, "[GL NV] GL_MAX_DRAW_MESH_TASKS_COUNT_NV = %i (at least: 65,535)", max_draw_mesh_tasks_count);
	glm::ivec3 max_mesh_work_group_size;
	glGetIntegeri_v(GL_MAX_MESH_WORK_GROUP_SIZE_NV, 0, &max_mesh_work_group_size.x);
	glGetIntegeri_v(GL_MAX_MESH_WORK_GROUP_SIZE_NV, 1, &max_mesh_work_group_size.y);
	glGetIntegeri_v(GL_MAX_MESH_WORK_GROUP_SIZE_NV, 2, &max_mesh_work_group_size.z);
	SDL_LogMessage(SDL_LOG_CATEGORY_APPLICATION, SDL_LOG_PRIORITY_INFO, "[GL NV] GL_MAX_MESH_WORK_GROUP_SIZE_NV = %i x %i x %i", max_mesh_work_group_size.x, max_mesh_work_group_size.y, max_mesh_work_group_size.z);
	glm::ivec3 max_task_work_group_size;
	glGetIntegeri_v(GL_MAX_TASK_WORK_GROUP_SIZE_NV, 0, &max_task_work_group_size.x);
	glGetIntegeri_v(GL_MAX_TASK_WORK_GROUP_SIZE_NV, 1, &max_task_work_group_size.y);
	glGetIntegeri_v(GL_MAX_TASK_WORK_GROUP_SIZE_NV, 2, &max_task_work_group_size.z);
	SDL_LogMessage(SDL_LOG_CATEGORY_APPLICATION, SDL_LOG_PRIORITY_INFO, "[GL NV] GL_MAX_TASK_WORK_GROUP_SIZE_NV = %i x %i x %i", max_task_work_group_size.x, max_task_work_group_size.y, max_task_work_group_size.z);
	GLint max_mesh_output_vertices;
	glGetIntegerv(GL_MAX_MESH_OUTPUT_VERTICES_NV, &max_mesh_output_vertices);
	SDL_LogMessage(SDL_LOG_CATEGORY_APPLICATION, SDL_LOG_PRIORITY_INFO, "[GL NV] GL_MAX_MESH_OUTPUT_VERTICES_NV = %i", max_mesh_output_vertices);
	GLint max_mesh_output_primitives;
	glGetIntegerv(GL_MAX_MESH_OUTPUT_PRIMITIVES_NV, &max_mesh_output_primitives);
	SDL_LogMessage(SDL_LOG_CATEGORY_APPLICATION, SDL_LOG_PRIORITY_INFO, "[GL NV] GL_MAX_MESH_OUTPUT_PRIMITIVES_NV = %i", max_mesh_output_primitives);
	GLint max_task_output;
	glGetIntegerv(GL_MAX_TASK_OUTPUT_COUNT_NV, &max_task_output);
	SDL_LogMessage(SDL_LOG_CATEGORY_APPLICATION, SDL_LOG_PRIORITY_INFO, "[GL NV] GL_MAX_TASK_OUTPUT_COUNT_NV = %i", max_task_output);
}

CMyApp::~CMyApp()
{
}

void CMyApp::SetupDebugCallback()
{
	// engedélyezzük és állítsuk be a debug callback függvényt ha debug context-ben vagyunk
	GLint context_flags;
	glGetIntegerv(GL_CONTEXT_FLAGS, &context_flags);
	if (context_flags & GL_CONTEXT_FLAG_DEBUG_BIT) {
		glEnable(GL_DEBUG_OUTPUT);
		glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);
		glDebugMessageControl(GL_DONT_CARE, GL_DONT_CARE, GL_DEBUG_SEVERITY_NOTIFICATION, 0, nullptr, GL_FALSE);
		glDebugMessageControl(GL_DONT_CARE, GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR, GL_DONT_CARE, 0, nullptr, GL_FALSE);
		glDebugMessageControl(GL_DONT_CARE, GL_DEBUG_TYPE_PERFORMANCE, GL_DONT_CARE, 0, nullptr, GL_FALSE);
		glDebugMessageCallback(SDL_GLDebugMessageCallback, nullptr);
	}
}

void CMyApp::InitShaders()
{
	m_programID = glCreateProgram();
	//AssembleProgram(m_programID, "Shaders/Vert_PosNormTexMPos.vert", "Shaders/Frag_LightingSimpleMPos.frag");
	// Same result
	ProgramBuilder{ m_programID }
		.ShaderStage(GL_VERTEX_SHADER	,"Shaders/Vert_PosNormTexMPos.vert")
		.ShaderStage(GL_FRAGMENT_SHADER	,"Shaders/Frag_LightingSimpleMPos.frag")
		.Link();

	InitAxesShader();
	InitSkyboxShaders();
	InitMeshShaders();
}

void CMyApp::CleanShaders()
{
	glDeleteProgram(m_programID);
	CleanAxesShader();
	CleanSkyboxShaders();
	CleanMeshShaders();
}

void CMyApp::InitMeshShaders()
{
	m_triangleMeshProgram = glCreateProgram();
	ProgramBuilder{ m_triangleMeshProgram }
		.ShaderStage(GL_MESH_SHADER_NV, "Shaders/Mesh_Meshtest.glsl")
		.ShaderStage(GL_FRAGMENT_SHADER, "Shaders/Frag_Meshtest.frag")
		.Link();

	m_tessProgram = glCreateProgram();
	ProgramBuilder{ m_tessProgram }
		.ShaderStage(GL_TASK_SHADER_NV,		"Shaders/MeshShader/Tess.task")
		.ShaderStage(GL_MESH_SHADER_NV,		"Shaders/MeshShader/Tess.mesh")
		.ShaderStage(GL_FRAGMENT_SHADER,	"Shaders/MeshShader/Frag_MeshDraw.frag")
		.Link();

	m_multipleObjProgram = glCreateProgram();
	ProgramBuilder{ m_multipleObjProgram }
		.ShaderStage(GL_TASK_SHADER_NV, "Shaders/MeshShader/Task_DrawMultipleObj.task")
		.ShaderStage(GL_MESH_SHADER_NV, "Shaders/MeshShader/Mesh_DrawMultipleObj.mesh")
		.ShaderStage(GL_FRAGMENT_SHADER, "Shaders/MeshShader/Frag_MeshDraw.frag")
		.Link();

	m_singleObjProgram = glCreateProgram();
	ProgramBuilder{ m_singleObjProgram }
		.ShaderStage(GL_TASK_SHADER_NV,		"Shaders/MeshShader/Task_DrawSingleObj.task")
		.ShaderStage(GL_MESH_SHADER_NV,		"Shaders/MeshShader/Mesh_DrawSingleObj.mesh")
		.ShaderStage(GL_FRAGMENT_SHADER,	"Shaders/MeshShader/Frag_MeshDraw.frag")
		.Link();
}

void CMyApp::CleanMeshShaders()
{
	glDeleteProgram(m_singleObjProgram);
	glDeleteProgram(m_multipleObjProgram);
	glDeleteProgram(m_triangleMeshProgram);
}

void CMyApp::InitAxesShader()
{
	m_programAxesID = glCreateProgram();
	ProgramBuilder{ m_programAxesID }
		.ShaderStage(GL_VERTEX_SHADER, "Shaders/Vert_axes.vert")
		.ShaderStage(GL_FRAGMENT_SHADER, "Shaders/Frag_Col.frag")
		.Link();
}

void CMyApp::CleanAxesShader()
{
	glDeleteProgram(m_programAxesID);
}

void CMyApp::InitSkyboxShaders()
{
	m_programSkyboxID = glCreateProgram();
	ProgramBuilder{ m_programSkyboxID }
		.ShaderStage(GL_VERTEX_SHADER, "Shaders/Vert_skybox.vert")
		.ShaderStage(GL_FRAGMENT_SHADER, "Shaders/Frag_skybox.frag")
		.Link();
}

void CMyApp::CleanSkyboxShaders()
{
	glDeleteProgram(m_programSkyboxID);
}

MeshObject<Vertex> initCube()
{
	MeshObject<Vertex> cubeMeshCPU = {};
	cubeMeshCPU.vertexArray =
	{
		// Front
		{ glm::vec3(-0.5, -0.5, +0.5), glm::vec3(0, 0, 1), glm::vec2(0, 0) },
		{ glm::vec3(+0.5, -0.5, +0.5), glm::vec3(0, 0, 1), glm::vec2(1, 0) },
		{ glm::vec3(-0.5, +0.5, +0.5), glm::vec3(0, 0, 1), glm::vec2(0, 1) },
		{ glm::vec3(+0.5, +0.5, +0.5), glm::vec3(0, 0, 1), glm::vec2(1, 1) },
		// Back
		{ glm::vec3(+0.5, -0.5, -0.5), glm::vec3(0, 0, -1), glm::vec2(0, 0) },
		{ glm::vec3(-0.5, -0.5, -0.5), glm::vec3(0, 0, -1), glm::vec2(1, 0) },
		{ glm::vec3(+0.5, +0.5, -0.5), glm::vec3(0, 0, -1), glm::vec2(0, 1) },
		{ glm::vec3(-0.5, +0.5, -0.5), glm::vec3(0, 0, -1), glm::vec2(1, 1) },
		// Right
		{ glm::vec3(+0.5, -0.5, +0.5), glm::vec3(1, 0, 0), glm::vec2(0, 0) },
		{ glm::vec3(+0.5, -0.5, -0.5), glm::vec3(1, 0, 0), glm::vec2(1, 0) },
		{ glm::vec3(+0.5, +0.5, +0.5), glm::vec3(1, 0, 0), glm::vec2(0, 1) },
		{ glm::vec3(+0.5, +0.5, -0.5), glm::vec3(1, 0, 0), glm::vec2(1, 1) },
		// Left
		{ glm::vec3(-0.5, -0.5, -0.5), glm::vec3(-1, 0, 0), glm::vec2(0, 0) },
		{ glm::vec3(-0.5, -0.5, +0.5), glm::vec3(-1, 0, 0), glm::vec2(1, 0) },
		{ glm::vec3(-0.5, +0.5, -0.5), glm::vec3(-1, 0, 0), glm::vec2(0, 1) },
		{ glm::vec3(-0.5, +0.5, +0.5), glm::vec3(-1, 0, 0), glm::vec2(1, 1) },
		// Top
		{ glm::vec3(-0.5, +0.5, +0.5), glm::vec3(0, 1, 0), glm::vec2(0, 0) },
		{ glm::vec3(+0.5, +0.5, +0.5), glm::vec3(0, 1, 0), glm::vec2(1, 0) },
		{ glm::vec3(-0.5, +0.5, -0.5), glm::vec3(0, 1, 0), glm::vec2(0, 1) },
		{ glm::vec3(+0.5, +0.5, -0.5), glm::vec3(0, 1, 0), glm::vec2(1, 1) },
		// Bottom
		{ glm::vec3(-0.5, -0.5, -0.5), glm::vec3(0, -1, 0), glm::vec2(0, 0) },
		{ glm::vec3(+0.5, -0.5, -0.5), glm::vec3(0, -1, 0), glm::vec2(1, 0) },
		{ glm::vec3(-0.5, -0.5, +0.5), glm::vec3(0, -1, 0), glm::vec2(0, 1) },
		{ glm::vec3(+0.5, -0.5, +0.5), glm::vec3(0, -1, 0), glm::vec2(1, 1) },
	};

	std::vector<GLuint> indices(36);
	int index = 0;
	for (int i = 0; i < 6 * 4; i += 4)
	{
		indices[index + 0] = i + 0;
		indices[index + 1] = i + 1;
		indices[index + 2] = i + 2;
		indices[index + 3] = i + 1;
		indices[index + 4] = i + 3;
		indices[index + 5] = i + 2;
		index += 6;
	}
	cubeMeshCPU.indexArray = std::move(indices);
	return cubeMeshCPU;
}

struct MySphereParam
{
	// (x, y, z) = ( r*cos(theta)*sin(phi), r*sin(theta)*sin(phi), r*cos(phi) )
	// where r is radius, theta [0,2*pi[, phi [0,pi[
	float radius;
	MySphereParam(float radius) : radius(radius) {}

	glm::vec3 GetPos(float u, float v) const noexcept
	{
		float theta = glm::pi<float>() * 2.0f * u;
		float phi	= glm::pi<float>() * v;

		return radius * glm::vec3(
						cos(theta) * sin(phi),
						cos(phi), 
						sin(theta) * sin(phi));
	}
	glm::vec3 GetNorm(float u, float v) const noexcept
	{
		float theta	= glm::pi<float>() * 2.0f * u;
		float phi	= glm::pi<float>() * v;

		return glm::vec3(
						cos(theta) * sin(phi),
						cos(phi),
						sin(theta) * sin(phi));
	}
	glm::vec2 GetTex(float u, float v) const noexcept
	{
		return glm::vec2(u, v);
	}
};

void CMyApp::InitGeometry()
{
	// Pyramid
	MeshObject<PaddedVertex> pyramidCPU = {
		{
			{ glm::vec3( 1,-1,-1),	glm::vec3( 0.0, 0.4472,-0.8944),	glm::vec2{ 0,	0 }  },
			{ glm::vec3(-1,-1,-1),	glm::vec3( 0.0, 0.4472,-0.8944),	glm::vec2{ 0,	1 }  },
			{ glm::vec3( 0, 1, 0),	glm::vec3( 0.0, 0.4472,-0.8944),	glm::vec2{ 1,	0.5f } },

			{ glm::vec3(1,-1, 1),	glm::vec3( 0.8944, 0.4472, 0.0),	glm::vec2{ 0,	0 } },
			{ glm::vec3(1,-1,-1),	glm::vec3( 0.8944, 0.4472, 0.0),	glm::vec2{ 1,	0.5f} },
			{ glm::vec3(0, 1, 0),	glm::vec3( 0.8944, 0.4472, 0.0),	glm::vec2{ 0,	1 } },

			{ glm::vec3(1,-1, 1),	glm::vec3( 0.0, 0.4472, 0.8944),	glm::vec2{ 0,	0 } },
			{ glm::vec3(0, 1, 0),	glm::vec3( 0.0, 0.4472, 0.8944),	glm::vec2{ 1,	0.5f} },
			{ glm::vec3(-1,-1, 1),	glm::vec3( 0.0, 0.4472, 0.8944),	glm::vec2{ 0,	1 }},

			{ glm::vec3(-1,-1, 1),	glm::vec3(-0.8944, 0.4472, 0.0),	glm::vec2{ 0,	0 } },
			{ glm::vec3(0, 1, 0),	glm::vec3(-0.8944, 0.4472, 0.0),	glm::vec2{ 0,	1 } },
			{ glm::vec3(-1,-1,-1),	glm::vec3(-0.8944, 0.4472, 0.0),	glm::vec2{ 1,	0.5f} },

			{ glm::vec3{  1, -1, -1 }, glm::vec3{ 0,-1 ,0 }, glm::vec2{ 1,	0 } },
			{ glm::vec3{ -1, -1, -1 }, glm::vec3{ 0,-1 ,0 }, glm::vec2{ 0,	0 } },
			{ glm::vec3{ -1, -1,  1 }, glm::vec3{ 0,-1 ,0 }, glm::vec2{ 0,	1 } },
			{ glm::vec3{  1, -1,  1 }, glm::vec3{ 0,-1 ,0 }, glm::vec2{ 1,	1 } },
		},
		{
			0,1,2,
			3,4,5,
			6,7,8,
			9,10,11,
			12,14,13,
			12,15,14
		}
	};
	auto pyramidMeshletsCPU = GenerateMeshlets(pyramidCPU);
	m_pyramidMeshlets.Init(pyramidMeshletsCPU.data(), pyramidMeshletsCPU.size(), STATIC_ONLY_BIT);

	for (auto& meshlet : pyramidMeshletsCPU) 
	{
		m_pyramidTriangleCount += meshlet.indexCount / 3;
	}

	// Cube
	MeshObject<Vertex> cubeMeshCPU = initCube();
	cubeGPU = CreateMeshForMeshShader(PaddedVertex::Convert(cubeMeshCPU));

	// Sphere
	// Input class instance needs to have GetPos(float,float) GetNorm(float,float) GetTex(float,float) function
	MeshObject<Vertex> sphereMeshCPU = GetParamSurfMesh(MySphereParam(1.0f), 20, 20);

	auto sphereMeshletsCPU = GenerateMeshlets(PaddedVertex::Convert(sphereMeshCPU));
	m_sphereMeshlets.Init(sphereMeshletsCPU.data(), sphereMeshletsCPU.size(), STATIC_ONLY_BIT);

	for (auto& meshlet : sphereMeshletsCPU)
	{
		m_suzanneTriangleCount += meshlet.indexCount / 3;
	}

	// Suzanne
	MeshObject<Vertex> suzanneMeshCPU = ObjParser::parse("Assets/Suzanne.obj");

	auto suzanneMeshletsCPU = GenerateMeshlets(PaddedVertex::Convert(suzanneMeshCPU));
	m_suzanneMeshlets.Init(suzanneMeshletsCPU.data(), suzanneMeshletsCPU.size(), STATIC_ONLY_BIT);

	for (auto& meshlet : suzanneMeshletsCPU)
	{
		m_suzanneTriangleCount += meshlet.indexCount / 3;
	}

	// Skybox
	InitSkyboxGeometry();
}

void CMyApp::CleanGeometry()
{
	m_sphereMeshlets.Clean();
	m_suzanneMeshlets.Clean();
	cubeGPU.Clean();
	m_pyramidMeshlets.Clean();

	CleanSkyboxGeometry();
}

void CMyApp::InitSkyboxGeometry()
{
	MeshObject<glm::vec3> skyboxCPU
	{
		std::vector<glm::vec3>
		{
			// Back side
			glm::vec3(-1, -1, -1),
			glm::vec3( 1, -1, -1),
			glm::vec3( 1,  1, -1),
			glm::vec3(-1,  1, -1),
			// Front side
			glm::vec3(-1, -1,  1),
			glm::vec3( 1, -1,  1),
			glm::vec3( 1,  1,  1),
			glm::vec3(-1,  1,  1),
		}, // 8 corner of the cube

		std::vector<GLuint>
		{
			// Back side
			0, 1, 2,
			2, 3, 0,
			// Front side
			4, 6, 5,
			6, 4, 7,
			// Left side
			0, 3, 4,
			4, 3, 7,
			// Right side
			1, 5, 2,
			5, 6, 2,
			// Bottom side
			1, 0, 4,
			1, 4, 5,
			// Top side
			3, 2, 6,
			3, 6, 7,
		}
	};

	m_Skybox = CreateGLObjectFromMesh(skyboxCPU, { { 0, offsetof( glm::vec3, x), 3, GL_FLOAT } } );
}

void CMyApp::CleanSkyboxGeometry()
{
	CleanOGLObject( m_Skybox );
}

void CMyApp::InitTextures()
{
	glCreateSamplers(1, &m_SamplerID);
	glSamplerParameteri(m_SamplerID, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glSamplerParameteri(m_SamplerID, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glSamplerParameteri(m_SamplerID, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glSamplerParameteri(m_SamplerID, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	ImageRGBA MossyImage = ImageFromFile( "Assets/mossy.png" );

	glCreateTextures( GL_TEXTURE_2D, 1, &m_MossyTextureID );
	glTextureStorage2D( m_MossyTextureID, NumberOfMIPLevels(MossyImage), GL_RGBA8, MossyImage.width, MossyImage.height );
	glTextureSubImage2D( m_MossyTextureID, 0, 0, 0, MossyImage.width, MossyImage.height, GL_RGBA, GL_UNSIGNED_BYTE, MossyImage.data() );

	glGenerateTextureMipmap( m_MossyTextureID );

	InitSkyboxTextures();
}

void CMyApp::CleanTextures()
{
	glDeleteTextures(1, &m_MossyTextureID);

	CleanSkyboxTextures();

	glDeleteTextures( 1, &m_SamplerID );
}

void CMyApp::InitSkyboxTextures()
{
	// skybox texture
	static const char* skyboxFiles[6] = {
		"Assets/xpos.png",
		"Assets/xneg.png",
		"Assets/ypos.png",
		"Assets/yneg.png",
		"Assets/zpos.png",
		"Assets/zneg.png",
	};

	ImageRGBA images[6];
	for (int i = 0; i < 6; ++i)
	{
		images[i] = ImageFromFile(skyboxFiles[i], false);
	}

	glCreateTextures(GL_TEXTURE_CUBE_MAP, 1, &m_SkyboxTextureID);
	glTextureStorage2D(m_SkyboxTextureID, 1, GL_RGBA8, images[0].width, images[0].height);

	for (int face = 0; face < 6; ++face)
	{
		glTextureSubImage3D(m_SkyboxTextureID, 0, 0, 0, face, images[face].width, images[face].height, 1, GL_RGBA, GL_UNSIGNED_BYTE, images[face].data());
	}

	glEnable(GL_TEXTURE_CUBE_MAP_SEAMLESS);
}

void CMyApp::CleanSkyboxTextures()
{
	glDeleteTextures(1, &m_SkyboxTextureID);
}

bool CMyApp::Init()
{
	SetupDebugCallback();

	// Set a bluish clear color
	// glClear() will use this for clearing the color buffer.
	glClearColor(0.125f, 0.25f, 0.5f, 1.0f);

	//
	// OpenGL
	//

	glEnable(GL_CULL_FACE);	 // Enable discarding the back-facing faces.
	glCullFace(GL_BACK);     // GL_BACK: facets facing away from camera, GL_FRONT: facets facing towards the camera
	glEnable(GL_DEPTH_TEST); // Enable depth testing. (for overlapping geometry)

	// Camera
	m_usedCamera.SetView(
		glm::vec3(5, 5, 5),	// From where we look at the scene - eye
		glm::vec3(0, 0, 0),	// Which point of the scene we are looking at - at
		glm::vec3(0, 1, 0)	// Upwards direction - up
	);
	m_cameraManipulator.SetStateFromCamera();

	//
	// Init functions
	//	

	InitGeometry();
	InitTextures();
	InitShaders(); // note: shaders might be recompiled of fixed function pipelines are changed

	{
		std::vector<glm::mat4> transforms(m_cubeNo);
		for (int i = 0; i < m_cubeNo; ++i)
		{
			glm::mat4 cubeWorld =
				glm::rotate(m_ElapsedTimeInSec + 2 * glm::pi<float>() / 10 * i, glm::vec3(0, 1, 0)) *
				glm::translate(glm::vec3(10 + 5 * sinf(m_ElapsedTimeInSec), 0, 0)) *
				glm::rotate((i + 1) * m_ElapsedTimeInSec * 0.5f, glm::vec3(1, 0, 0)) *
				glm::rotate((m_cubeNo - i) * m_ElapsedTimeInSec * 0.3f, glm::vec3(0, 1, 0)) *
				glm::scale(glm::vec3(1.0));

			transforms[i] = cubeWorld;
		}
		m_cubeTransforms.Init(transforms.data(), m_cubeNo, ALLOW_MAP_WRITE_BIT);
	}

	m_cubeVisible.Init(m_isVisible.data(), m_cubeNo, ALLOW_MAP_WRITE_BIT);

	return true;
}

void CMyApp::Clean()
{
	CleanGeometry();
	CleanTextures();
	CleanShaders();

	m_cubeTransforms.Clean();
	m_cubeVisible.Clean();
}

void CMyApp::Update(const SUpdateInfo& updateInfo)
{
	m_ElapsedTimeInSec = updateInfo.ElapsedTimeInSec;
	m_delta_time = updateInfo.DeltaTimeInSec;

	m_cameraManipulator.Update(updateInfo.DeltaTimeInSec);

	// 
	// Update cube transforms
	// 
	{
		std::vector<glm::mat4> transforms(m_cubeNo);
		for (int i = 0; i < m_cubeNo; ++i)
		{
			glm::mat4 cubeWorld =
				glm::rotate(m_ElapsedTimeInSec + 2 * glm::pi<float>() / 10 * i, glm::vec3(0, 1, 0)) *
				glm::translate(glm::vec3(10 + 5 * sinf(m_ElapsedTimeInSec), 0, 0)) *
				glm::rotate((i + 1) * m_ElapsedTimeInSec * 0.5f, glm::vec3(1, 0, 0)) *
				glm::rotate((m_cubeNo - i) * m_ElapsedTimeInSec * 0.3f, glm::vec3(0, 1, 0)) *
				glm::scale(glm::vec3(1.0));

			transforms[i] = cubeWorld;
		}

		auto ptr = m_cubeTransforms.MapBuffer(WRITE_ONLY);
		std::memcpy(ptr, transforms.data(), transforms.size() * sizeof(transforms[0]));
		m_cubeTransforms.UnmapBuffer();
	}
}

void CMyApp::DrawAxes()
{
	// We always want to see it, regardless of whether there is an object in front of it
	glDisable(GL_DEPTH_TEST);
	GLfloat prevLineWidth = 0.0f;
	glGetFloatv(GL_LINE_WIDTH, &prevLineWidth);
	glLineWidth(1.0f);
	glUseProgram(m_programAxesID);

	glm::mat4 axisWorld = (m_lockAxesToCamera) ? glm::translate(m_usedCamera.GetAt()) : glm::identity<glm::mat4>(); // glm::identity<glm::mat4>() == glm::mat4(1.0f)
	glUniformMatrix4fv(ul("viewProj"), 1, GL_FALSE, glm::value_ptr(m_usedCamera.GetViewProj()));
	glUniformMatrix4fv(ul("world"), 1, GL_FALSE, glm::value_ptr(axisWorld));

	glDrawArrays(GL_LINES, 0, 6);
	glEnable(GL_DEPTH_TEST);
	glLineWidth(prevLineWidth);
	glUseProgram(0);
}

void CMyApp::DrawSkybox()
{
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_CUBE_MAP, m_SkyboxTextureID);

	glUseProgram(m_programSkyboxID);

	glUniform1i(ul("skyboxTexture"), 0);
	glUniformMatrix4fv(ul("viewProj"), 1, GL_FALSE, glm::value_ptr(m_usedCamera.GetViewProj()));
	glUniformMatrix4fv(ul("world"), 1, GL_FALSE, glm::value_ptr(glm::translate(m_usedCamera.GetEye())));

	// Save the last Z-test, namely the relation by which we update the pixel.
	GLint prevDepthFnc;
	glGetIntegerv(GL_DEPTH_FUNC, &prevDepthFnc);

	// Now we use less-then-or-equal, because we push everything to the far clipping plane
	glDepthFunc(GL_LEQUAL);

	glBindVertexArray(m_Skybox.vaoID);
	glDrawElements(GL_TRIANGLES, m_Skybox.count, GL_UNSIGNED_INT, nullptr);

	glDepthFunc(prevDepthFnc);

	glUseProgram(0);
	glBindVertexArray(0);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
}

void CMyApp::DrawMeshTriangle()
{
	//
	//	Mesh shader program
	//
	glUseProgram(m_triangleMeshProgram);

	glDrawMeshTasksNV(
		0,	// first index
		1	// number of workgroups launched
	);

	glUseProgram(0);
}

void CMyApp::DrawMainScene()
{
	if (m_wireframeMode) glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	glUseProgram(m_multipleObjProgram);

	glUniformMatrix4fv(ul("viewProj"), 1, GL_FALSE, glm::value_ptr(m_usedCamera.GetViewProj())); 	

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, m_MossyTextureID); 
	glUniform1i(ul("texImage"),0);				

	glUniform3fv(ul("light_dir"), 1, glm::value_ptr(m_lightDir));
	glUniform3fv(ul("La"), 1, glm::value_ptr(m_La));
	glUniform3fv(ul("Ld"), 1, glm::value_ptr(m_Ld));

	glUniform1i(ul("showMeshlets"), m_showMeshShaderGroups);
	glUniform1i(ul("showTaskGroups"), m_showTaskWorkgroups);

	// 
	// Draw cubes
	// 
	{
		glUniform1ui(ul("triangleCount"), (cubeGPU.indexBuffer.GetCount() / 3));
		glUniform1ui(ul("meshNo"), m_cubeNo);

		m_cubeVisible.Bind(SHADER_STORAGE, 4);
		m_cubeTransforms.Bind(SHADER_STORAGE, 3);
		
		// We use SSBOs to hold our vertex/index array
		cubeGPU.Bind();

		// Initiate task shader workgroups
		glDrawMeshTasksNV(
			0,	// first index
			5	// number of workgroups launched
		);
		cubeGPU.UnBind();
		m_cubeTransforms.UnBind();
		m_cubeVisible.UnBind();
	}

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, 0);
	glUseProgram(0);
	
	glUseProgram(m_singleObjProgram);


	glUniformMatrix4fv(ul("viewProj"), 1, GL_FALSE, glm::value_ptr(m_usedCamera.GetViewProj()));

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, m_MossyTextureID);
	glUniform1i(ul("texImage"), 0);

	glUniform3fv(ul("light_dir"), 1, glm::value_ptr(m_lightDir));
	glUniform3fv(ul("La"), 1, glm::value_ptr(m_La));
	glUniform3fv(ul("Ld"), 1, glm::value_ptr(m_Ld));

	glUniform1i(ul("showMeshlets"), m_showMeshShaderGroups);

	const size_t groupSize = 1;

	// 
	// Draw pyramid
	//
	{
		glm::mat4 pyramidWorld =
			glm::translate(glm::vec3(0.0f, 1.0f, 0.0f));
		glUniformMatrix4fv(ul("world"), 1, GL_FALSE, glm::value_ptr(pyramidWorld));
		glUniformMatrix4fv(ul("worldIT"), 1, GL_FALSE, glm::value_ptr(glm::transpose(glm::inverse(pyramidWorld))));

		glUniform1ui(ul("triangleCount"), m_pyramidTriangleCount);
		glUniform1ui(ul("meshletCount"), m_pyramidMeshlets.GetCount());

		m_pyramidMeshlets.Bind(SHADER_STORAGE, 1);
		glDrawMeshTasksNV(0,1);
		m_pyramidMeshlets.UnBind();
	}

	/// 
	/// Draw suzanne
	/// 
	{
		glm::mat4 suzanneWorld = glm::translate(glm::vec3(0.0f, 3.0f, -0.5f));
		glUniformMatrix4fv(ul("world"), 1, GL_FALSE, glm::value_ptr(suzanneWorld));
		glUniformMatrix4fv(ul("worldIT"), 1, GL_FALSE, glm::value_ptr(glm::transpose(glm::inverse(suzanneWorld))));

		glUniform1ui(ul("triangleCount"), m_suzanneTriangleCount);
		glUniform1ui(ul("meshletCount"), m_suzanneMeshlets.GetCount());

		m_suzanneMeshlets.Bind(SHADER_STORAGE, 1);
		glDrawMeshTasksNV(0, m_suzanneMeshlets.GetCount());
		m_suzanneMeshlets.UnBind();
	}

	///// 
	///// Draw Sphere
	///// 
	//{
	//	glm::mat4 sphereWorld = glm::translate(glm::vec3(0.0f, -1.0f, 0.0f));
	//	glUniformMatrix4fv(ul("world"), 1, GL_FALSE, glm::value_ptr(sphereWorld));
	//	glUniformMatrix4fv(ul("worldIT"), 1, GL_FALSE, glm::value_ptr(glm::transpose(glm::inverse(sphereWorld))));

	//	glUniform1ui(ul("triangleCount"), m_suzanneTriangleCount);
	//	glUniform1ui(ul("meshletCount"), m_suzanneMeshlets.GetCount());

	//	m_sphereMeshlets.Bind(SHADER_STORAGE, 1);
	//	glDrawMeshTasksNV(0, 1);
	//	m_sphereMeshlets.UnBind();
	//}

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, 0);
	glUseProgram(0);

	if (m_wireframeMode) glPolygonMode(GL_FRONT, GL_FILL);
}

void CMyApp::DrawTessScene()
{
	if (m_wireframeMode) glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	glUseProgram(m_tessProgram);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, m_MossyTextureID);
	glUniform1i(ul("texImage"), 0);

	glUniform3fv(ul("light_dir"), 1, glm::value_ptr(m_lightDir));
	glUniform3fv(ul("La"), 1, glm::value_ptr(m_La));
	glUniform3fv(ul("Ld"), 1, glm::value_ptr(m_Ld));

	glUniformMatrix4fv(ul("viewProj"), 1, GL_FALSE, glm::value_ptr(m_usedCamera.GetViewProj()));
	glUniformMatrix4fv(ul("world"), 1, GL_FALSE, glm::value_ptr(glm::mat4(1)));
	glUniformMatrix4fv(ul("worldIT"), 1, GL_FALSE, glm::value_ptr(glm::mat4(1)));

	glDrawMeshTasksNV(0, 1);

	glUseProgram(0);

	if (m_wireframeMode) glPolygonMode(GL_FRONT, GL_FILL);
}

void CMyApp::Render()
{
	// Clear the framebuffer (GL_COLOR_BUFFER_BIT) and the depth buffer (GL_DEPTH_BUFFER_BIT)
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	switch (m_currentSceneID)
	{
	case DRAW_TRIANGLE_DEMO: DrawMeshTriangle(); break;
	case DRAW_SUZANNE_DEMO: DrawMainScene(); break;
	case DRAW_TESS_DEMO: DrawTessScene(); break;
	default:
		break;
	}

	DrawSkybox();
	DrawAxes();
}

void CMyApp::RenderGUI()
{
	// ImGui DemoWindow
	
	if (ImGui::BeginMainMenuBar())
	{
		//
		// FPS calculation
		//
		{
			static float refresh_time = 0.1f;
			static float timer = 0;
			static int   frameCount = 0;
			static float fps = 0;

			timer += static_cast<float>(m_delta_time);
			++frameCount;
			if (timer > refresh_time) {
				fps = frameCount / timer;
				timer = 0;
				frameCount = 0;
			}
			ImGui::Text("FPS: %d", static_cast<int>(fps));

			if (ImGui::BeginMenu("FPS settings"))
			{
				ImGui::PushItemWidth(150.0f);
				ImGui::SliderFloat("Refresh time for the FPS counter", &refresh_time, 0.01f, 1.0f);
				ImGui::PopItemWidth();

				ImGui::Checkbox("Lock axes to the camera's look at point", &m_lockAxesToCamera);

				ImGui::EndMenu();
			}

			ImGui::Separator();

			static float linewidth = 1.0f;
			if (ImGui::Checkbox("Wireframe mode",&m_wireframeMode)) 
			{
			}
			if (m_wireframeMode) {
				ImGui::PushItemWidth(150.0f);
				if (ImGui::SliderFloat("Linewidth", &linewidth, 0.1f, 10.0f)) 
				{
					glLineWidth(linewidth);
				}
			}
		}

		ImGui::Separator();

		ImGui::PushItemWidth(150.0f);
		ImGui::Checkbox("Show meshlets", &m_showMeshShaderGroups);

		if (m_showMeshShaderGroups)
		{
			ImGui::Separator();

			ImGui::PushItemWidth(250.0f);
			ImGui::Checkbox("Show task workgroups for boxes", &m_showTaskWorkgroups);
		}

		ImGui::Separator();
		//
		// Scene selection
		//
		{
			static const char* scenes[]{
				"MESH SCREEN TRIANGLE DEMO",
				"MESH DRAW DEMO",
				"MESH TESS DEMO"
			};

			ImGui::Text("Current scene: ");

			if (ImGui::BeginMenu(scenes[m_currentSceneID]))
			{
				ImGui::Separator();

				for (int i = 0; i < (sizeof(scenes) / sizeof(scenes[0])); ++i)
				{
					if (ImGui::MenuItem(scenes[i])) { m_currentSceneID = i; }
				}

				ImGui::EndMenu();
			}
		}

		ImGui::EndMainMenuBar();
	}

	// We set the size and position when we first run the program
	// (when the window is not in th imgui.ini file)
	ImGui::SetNextWindowPos(ImVec2(35, 85), ImGuiCond_FirstUseEver);
	ImGui::SetNextWindowSize(ImVec2(800, 150), ImGuiCond_FirstUseEver);
	if (ImGui::Begin("ImGui example")) // Inner code runs when ImGui window is open
	{
		if (ImGui::CollapsingHeader("Options"))
		{
			if (m_currentSceneID == DRAW_SUZANNE_DEMO)
			{
				static std::random_device rd;
				static std::mt19937 mt(rd());
				static std::uniform_int_distribution<int> random(0, m_cubeNo - 1);

				if (ImGui::Button("Change Random")) {
					int randomIndx = random(mt);
					auto& visible = m_isVisible[randomIndx];
					visible = !visible;
					
					auto ptr = m_cubeVisible.MapBufferRange(randomIndx, 1, MAP_WRITE_BIT);
					std::memcpy(
						ptr,
						&visible,
						m_cubeVisible.GetElementSize()
					);
					m_cubeVisible.UnmapBuffer();
				}
				ImGui::SameLine();
				ImGui::Text("Trigger the visibility of one random cube");
			}
		}
	}
	ImGui::End();
}

GLint CMyApp::ul(const char* uniformName) noexcept
{
	GLuint programID = 0;

	// Get the current program ID
	// https://registry.khronos.org/OpenGL-Refpages/gl4/html/glGet.xhtml
	glGetIntegerv(GL_CURRENT_PROGRAM, reinterpret_cast<GLint*>(&programID));
	// Knowing the program and the name of the uniform, let's get the location!
	// https://registry.khronos.org/OpenGL-Refpages/gl4/html/glGetUniformLocation.xhtml
	return glGetUniformLocation(programID, uniformName);
}

// https://wiki.libsdl.org/SDL2/SDL_KeyboardEvent
// https://wiki.libsdl.org/SDL2/SDL_Keysym
// https://wiki.libsdl.org/SDL2/SDL_Keycode
// https://wiki.libsdl.org/SDL2/SDL_Keymod

void CMyApp::KeyboardDown(const SDL_KeyboardEvent& key)
{
	if (key.repeat == 0) // Triggers only once when held
	{
		if (key.key == SDLK_F5 && key.key & SDL_KMOD_CTRL) // CTRL + F5
		{
			CleanShaders();
			InitShaders();
		}
		if (key.key == SDLK_F1) // F1
		{
			GLint polygonModeFrontAndBack[2] = {};
			// https://registry.khronos.org/OpenGL-Refpages/gl4/html/glGet.xhtml
			glGetIntegerv(GL_POLYGON_MODE, polygonModeFrontAndBack); // Query the current polygon mode. It gives the front and back modes separately.
			GLenum polygonMode = (polygonModeFrontAndBack[0] != GL_FILL ? GL_FILL : GL_LINE); // Switch between FILL and LINE
			// https://registry.khronos.org/OpenGL-Refpages/gl4/html/glPolygonMode.xhtml
			glPolygonMode(GL_FRONT_AND_BACK, polygonMode); // Set the new polygon mode
		}
	}
	m_cameraManipulator.KeyboardDown(key);
}

void CMyApp::KeyboardUp(const SDL_KeyboardEvent& key)
{
	m_cameraManipulator.KeyboardUp(key);
}

// https://wiki.libsdl.org/SDL2/SDL_MouseMotionEvent

void CMyApp::MouseMove(const SDL_MouseMotionEvent& mouse)
{
	m_cameraManipulator.MouseMove(mouse);
}

// https://wiki.libsdl.org/SDL2/SDL_MouseButtonEvent

void CMyApp::MouseDown(const SDL_MouseButtonEvent& mouse)
{
}

void CMyApp::MouseUp(const SDL_MouseButtonEvent& mouse)
{
}

// https://wiki.libsdl.org/SDL2/SDL_MouseWheelEvent

void CMyApp::MouseWheel(const SDL_MouseWheelEvent& wheel)
{
	m_cameraManipulator.MouseWheel(wheel);
}

// New window size
void CMyApp::Resize(int _w, int _h)
{
	glViewport(0, 0, _w, _h);
	m_usedCamera.SetAspect(static_cast<float>(_w) / _h);
}

// Other SDL events
// https://wiki.libsdl.org/SDL2/SDL_Event

void CMyApp::OtherEvent(const SDL_Event& ev)
{
}