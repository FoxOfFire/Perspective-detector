#include "CameraManipulator.h"

#include "Camera.h"

#include <SDL3/SDL.h>

CameraManipulator::CameraManipulator(Camera &camera): m_rCamera(camera)
{
}

CameraManipulator::~CameraManipulator()
{
}

void CameraManipulator::SetStateFromCamera()
{
  	// A kezdeti gömbkoordináták beállítása. 
    m_center = m_rCamera.GetAt();
    glm::vec3 ToAim = m_center - m_rCamera.GetEye();

    m_distance = glm::length( ToAim );

    m_u = atan2f( ToAim.z, ToAim.x );
    m_v = acosf( ToAim.y / m_distance );

    m_worldUp = m_rCamera.GetWorldUp();
}

void CameraManipulator::Update( float _deltaTime )
{
	// Frissítjük a kamerát a Model paraméterek alapján. 

	// Az új nézési irányt a gömbi koordináták alapján számoljuk ki. 
    glm::vec3 lookDirection( cosf(m_u) * sinf(m_v),
                             cosf(m_v), 
                             sinf(m_u) * sinf(m_v) );
	// Az új kamera pozíciót a nézési irány és a távolság alapján számoljuk ki. 
    glm::vec3 eye = m_center - m_distance * lookDirection;

	// Az új felfelé irány a világ felfelével legyen azonos. 
    glm::vec3 up = m_worldUp;

	// Az új jobbra irányt a nézési irány és a felfelé irány keresztszorzatából számoljuk ki. 
    glm::vec3 right = glm::normalize( glm::cross( lookDirection, up ) );

	// Az új előre irányt a felfelé és jobbra irányok keresztszorzatából számoljuk ki. 
    glm::vec3 forward = glm::cross( up, right);

	// Az új elmozdulásat a kamera mozgás irányának és sebességének a segítségével számoljuk ki. 
    glm::vec3 deltaPosition = ( m_goForward * forward + m_goRight * right + m_goUp * up ) * m_speed * _deltaTime;

	// Az új kamera pozíciót és nézési cél pozíciót beállítjuk. 
    eye += deltaPosition;
    m_center += deltaPosition;   

	// Frissítjük a kamerát az új pozícióval és nézési iránnyal. 
    m_rCamera.SetView( eye, m_center, m_worldUp );
}


void CameraManipulator::KeyboardDown(const SDL_KeyboardEvent& key)
{
	switch ( key.key )
	{
	case SDLK_LSHIFT:
	case SDLK_RSHIFT:
		if ( !key.repeat ) m_speed /= 4.0f;
		break;
	case SDLK_W:
		m_goForward = 1;
		break;
	case SDLK_S:
		m_goForward = -1;
		break;
	case SDLK_A:
		m_goRight = -1;
		break;
	case SDLK_D:
		m_goRight = 1;
		break;
	case SDLK_E:
		m_goUp = 1;
		break;
	case SDLK_Q:
		m_goUp = -1;
		break;
	}
}

void CameraManipulator::KeyboardUp(const SDL_KeyboardEvent& key)
{
	
	switch ( key.key )
	{
	case SDLK_LSHIFT:
	case SDLK_RSHIFT:
		m_speed *= 4.0f;
		break;
	case SDLK_W:
	case SDLK_S:
		m_goForward = 0;
		break;
	case SDLK_A:
	case SDLK_D:
		m_goRight = 0;
		break;
	case SDLK_Q:
	case SDLK_E:
		m_goUp = 0;
		break;
	}
}


void CameraManipulator::MouseMove(const SDL_MouseMotionEvent& mouse)
{
	if ( mouse.state & SDL_BUTTON_LMASK )
	{
		float du = mouse.xrel / 100.0f;
		float dv = mouse.yrel / 100.0f;

		m_u += du;
		m_v = glm::clamp<float>( m_v + dv, 0.1f, 3.1f );
	}
	if ( mouse.state & SDL_BUTTON_RMASK )
	{
		m_distance *= pow( 0.9f, mouse.yrel / 50.0f );
	}
}

void CameraManipulator::MouseWheel(const SDL_MouseWheelEvent& wheel)
{
	m_distance *= powf( 0.9f, static_cast<float>( wheel.y ) );
}