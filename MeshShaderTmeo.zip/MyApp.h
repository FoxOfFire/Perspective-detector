#pragma once

// GLM
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>

// GLEW
#include <GL/glew.h>

// SDL
#include <SDL3/SDL.h>
#include <SDL3/SDL_opengl.h>

// Utils
#include "GLUtils.hpp"
#include "Camera.h"
#include "CameraManipulator.h"

#include "GLMeshShaderUtils.h"

// Standard
#include <array>

enum SceneIds {
	DRAW_TRIANGLE_DEMO	= 0,
	DRAW_SUZANNE_DEMO = 1,
	DRAW_TESS_DEMO = 2
};

struct SUpdateInfo
{
	float ElapsedTimeInSec = 0.0f;	// Elapsed time since start of the program
	float DeltaTimeInSec = 0.0f;	// Elapsed time since last update
};

class CMyApp
{
public:
	CMyApp();
	~CMyApp();

	bool Init();
	void Clean();

	void Update(const SUpdateInfo&);
	void DrawMeshTriangle();
	void DrawMainScene();
	void DrawTessScene();
	void Render();
	void RenderGUI();

	void KeyboardDown(const SDL_KeyboardEvent&);
	void KeyboardUp(const SDL_KeyboardEvent&);
	void MouseMove(const SDL_MouseMotionEvent&);
	void MouseDown(const SDL_MouseButtonEvent&);
	void MouseUp(const SDL_MouseButtonEvent&);
	void MouseWheel(const SDL_MouseWheelEvent&);
	void Resize(int, int);

	void OtherEvent(const SDL_Event&);
protected:
	void SetupDebugCallback();

	//
	// Variables
	//

	float	m_ElapsedTimeInSec		= 0.0f;
	float	m_delta_time			= 0.0f;
	bool	m_lockAxesToCamera		= false;
	bool	m_wireframeMode			= false;
	bool	m_showMeshShaderGroups	= false;
	bool	m_showTaskWorkgroups	= false;

	int		m_currentSceneID	= DRAW_TESS_DEMO;

	// Description of the cubes
	std::array<uint32_t, 10> m_isVisible;
	const int m_cubeNo = static_cast<int>(m_isVisible.size());

	enum CameraIds {
		PRIMARY_CAMERA		= 0,
		SECONDARY_CAMERA	= 1
	};

	// Camera
	size_t m_currentCamera = PRIMARY_CAMERA;
	Camera m_usedCamera;
	CameraManipulator m_cameraManipulator;

	//
	// OpenGL stuff
	//

	void DrawAxes();
	void DrawSkybox();
	// Uniform location query
	static GLint ul(const char* uniformName) noexcept;

	// Shader variables
	GLuint m_programID = 0;				// Shader of the objects
	GLuint m_programAxesID = 0;			// Program showing X,Y,Z directions
	GLuint m_programSkyboxID = 0;		// Skybox program
	GLuint m_triangleMeshProgram = 0;	// Mesh

	GLuint m_multipleObjProgram = 0;
	GLuint m_singleObjProgram = 0;
	GLuint m_tessProgram = 0;

	// Light source
	glm::vec3 m_lightDir = glm::vec3(-1, -2, -0.5);
	glm::vec3 m_La = glm::vec3(0.0, 0.0, 0.0);	// Ambient
	glm::vec3 m_Ld = glm::vec3(1.0, 1.0, 1.0);	// Diffuse

	// Shader initialization and termination
	void InitShaders();
	void CleanShaders();
	void InitMeshShaders();
	void CleanMeshShaders();
	void InitAxesShader();
	void CleanAxesShader();
	void InitSkyboxShaders();
	void CleanSkyboxShaders();
	
	// 
	// Geometry variables
	// 
	OGLObject m_Skybox	= {};

	// 
	// Buffers
	// 
	GLImmutableBuffer<uint32_t> m_cubeVisible = {};
	GLImmutableBuffer<glm::mat4> m_cubeTransforms = {};

	//
	// Mesh shader objects
	//
	MeshShaderObject<PaddedVertex> cubeGPU;

	// 
	// Meshlet buffers
	// 
	size_t m_pyramidTriangleCount = 0;
	GLImmutableBuffer<Meshlet<PaddedVertex>> m_pyramidMeshlets = {};
	size_t m_suzanneTriangleCount = 0;
	GLImmutableBuffer<Meshlet<PaddedVertex>> m_suzanneMeshlets = {};
	size_t m_sphereTriangleCount = 0;
	GLImmutableBuffer<Meshlet<PaddedVertex>> m_sphereMeshlets = {};

	// Geometry initialization and termination
	void InitGeometry();
	void CleanGeometry();
	void InitSkyboxGeometry();
	void CleanSkyboxGeometry();

	// Texture variables
	GLuint m_SamplerID = 0;
	GLuint m_MossyTextureID	= 0;
	GLuint m_SkyboxTextureID = 0;

	// Texture initialization and termination
	void InitTextures();
	void CleanTextures();
	void InitSkyboxTextures();
	void CleanSkyboxTextures();
};